# src/agent.py
import logging
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

from .db import get_sql_db
from .llm import get_llm

# ────────────────────────────────────────────────────────────────
# Prompt with schema-prefix guard-rail
# ────────────────────────────────────────────────────────────────
system_message = """
You are an agent designed to interact with a SQL database.
Given an input question, create a syntactically correct {dialect} query to run,
then look at the results of the query and answer the question. Unless the user
specifies a specific number of examples, always limit the query to at most
{top_k} rows.

You MUST double-check your query before executing it. If you get an error,
rewrite the query and try again.
"""

extra_rules = """
Always reference the table as affinius_dbt.compstak_lease_geo.
Never omit the schema prefix.
"""

prompt = system_message + extra_rules  # ← combined prefix


# ────────────────────────────────────────────────────────────────
# Agent builder
# ────────────────────────────────────────────────────────────────
def build_agent(top_k: int = 10, verbose: bool = True):
    """
    Construct and return a LangChain SQL agent wired to:
      • Amazon Redshift (via get_sql_db)
      • Claude 3.5 Sonnet on Bedrock (via get_llm)
    """
    llm = get_llm()
    db  = get_sql_db()

    logging.info("[2.5/4] 🛠️  Initialising LangChain SQL toolkit")
    toolkit = SQLDatabaseToolkit(db=db, llm=llm)

    agent = create_sql_agent(
        llm=llm,
        toolkit=toolkit,
        top_k=top_k,
        agent_type="tool-calling",          # avoids circular-ref bug
        verbose=verbose,
        prefix=prompt,                      # <- custom prompt with rules
        agent_executor_kwargs={
            "callbacks": [StreamingStdOutCallbackHandler()],
        },
    )

    return agent

