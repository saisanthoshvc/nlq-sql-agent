# src/db.py
"""
Database helpers

• get_sqlalchemy_engine() – creates a SQLAlchemy engine with IAM or password auth
• get_sql_db()           – returns a LangChain SQLDatabase limited to
                            affinius_dbt.compstak_lease_geo
"""

import logging
import sqlalchemy as sa
from sqlalchemy.engine import Engine                     # ← explicit import
import redshift_connector
from langchain_community.utilities.sql_database import SQLDatabase

from .config import RS


# ──────────────────────────────────────────────────────────────────────────────
# Engine factory
# ──────────────────────────────────────────────────────────────────────────────
def get_sqlalchemy_engine() -> Engine:
    logging.info("[2/4] 🗄️  Connecting to Amazon Redshift")

    if RS["iam"]:
        conn = redshift_connector.connect(
            iam=True,
            host=RS["host"],
            database=RS["db"],
            port=RS["port"],
            cluster_identifier=RS["cluster"],
            user=RS["user"] or None,
        )
        return sa.create_engine("redshift+redshift_connector://", creator=lambda: conn)

    url = sa.engine.URL.create(
        "redshift+redshift_connector",
        username=RS["user"],
        password=RS["pwd"],
        host=RS["host"],
        port=RS["port"],
        database=RS["db"],
    )
    return sa.create_engine(url)


# ──────────────────────────────────────────────────────────────────────────────
# LangChain SQLDatabase (restricted)
# ──────────────────────────────────────────────────────────────────────────────
def get_sql_db() -> SQLDatabase:
    """
    Return a SQLDatabase object **restricted to a single table** so the agent
    skips catalog scans and starts answering immediately.
    """
    engine = get_sqlalchemy_engine()

    return SQLDatabase(
        engine,
	include_tables=["compstak_lease_geo"],
        schema="affinius_dbt",                 # Redshift external schema
        sample_rows_in_table_info=0,           # skip SELECT * probes
    )

