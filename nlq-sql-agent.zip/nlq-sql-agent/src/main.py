# src/main.py
import logging, typer                 # <-- add these
from rich import print

from src.utils.logging_config import setup_logging
from src.agent import build_agent      # <-- fully-qualified import

cli = typer.Typer()

@cli.command()
def ask(question: str):
    """
    Run an NLQ against Redshift via Claude SQL-agent.
    """
    setup_logging(logging.INFO)
    agent = build_agent()
    logging.info("[3/4] 🚀 Running agent\n")
    response = agent.invoke({"input": question})
    logging.info("[4/4] ✅ Done\n")
    print("[bold green]Answer:[/]", response)

if __name__ == "__main__":
    cli()

