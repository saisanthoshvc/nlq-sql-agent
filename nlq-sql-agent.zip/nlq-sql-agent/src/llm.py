from langchain_aws.chat_models.bedrock import ChatBedrock
import boto3, logging
from .config import MODEL_ID, REGION, USE_CONVERSE

def get_llm():
    logging.info("[1/4] 🔌 Initialising Bedrock client/LLM")
    client = boto3.client("bedrock-runtime", region_name=REGION)
    llm = ChatBedrock(
        client=client,
        model_id=MODEL_ID,
        model_kwargs={
            "max_tokens": 4096,
            "temperature": 0.0,
            "top_p": 0.9,
        },
        beta_use_converse_api=USE_CONVERSE,
    )
    return llm

