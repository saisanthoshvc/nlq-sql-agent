from pathlib import Path
from dotenv import load_dotenv
import os

load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)

REGION          = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID        = os.environ["BEDROCK_MODEL_ID"]
USE_CONVERSE    = os.getenv("BEDROCK_USE_CONVERSE", "false").lower() == "true"

RS = {
    "host":     os.environ["REDSHIFT_HOST"],
    "port":     int(os.getenv("REDSHIFT_PORT", 5439)),
    "db":       os.environ["REDSHIFT_DB"],
    "user":     os.getenv("REDSHIFT_USER"),
    "pwd":      os.getenv("REDSHIFT_PASSWORD"),
    "iam":      os.getenv("REDSHIFT_IAM", "false").lower() == "true",
}

